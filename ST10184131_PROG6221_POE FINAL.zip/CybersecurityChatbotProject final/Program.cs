using System;

namespace ConsoleChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Chatbot";
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔════════════════════════════════════╗");
            Console.WriteLine("║  🛡️ Welcome to CyberChatbot SA 🇿🇦  ║");
            Console.WriteLine("╚════════════════════════════════════╝\n");

            Console.ResetColor();
            Console.Write("👤 Please enter your name: ");
            string name = Console.ReadLine();

            Console.WriteLine($"\nHello, {name}! Let's improve your cybersecurity awareness.");
            Console.WriteLine("\nWhat would you like to learn about?");
            Console.WriteLine("1️⃣ Strong Passwords");
            Console.WriteLine("2️⃣ Phishing Scams");
            Console.WriteLine("3️⃣ Secure Wi-Fi");
            Console.WriteLine("4️⃣ Exit");

            while (true)
            {
                Console.Write("\nEnter your choice (1–4): ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.WriteLine("🔐 Use passwords that are 12+ characters, and include numbers, letters & symbols.");
                        break;
                    case "2":
                        Console.WriteLine("📧 Watch out for phishing! Don’t click on strange links in emails or SMS.");
                        break;
                    case "3":
                        Console.WriteLine("📶 Use WPA3 security on your router and change the default password.");
                        break;
                    case "4":
                        Console.WriteLine($"\n👋 Goodbye, {name}! Stay cyber-safe.");
                        return;
                    default:
                        Console.WriteLine("❌ Invalid choice. Please choose between 1 and 4.");
                        break;
                }
            }
        }
    }
}
