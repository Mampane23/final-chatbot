
# Cybersecurity Awareness Chatbot

This project includes both a WPF (GUI) and Console version of a Cybersecurity Awareness Chatbot for South African citizens.

## Features

- Task Management (Add, Remove, List tasks)
- Reminders (e.g., "remind me to update password in 3 days")
- Quiz mini-game for cybersecurity awareness
- Keyword-based responses (e.g., "What is phishing?")
- WPF User Interface (GUI)
- ASCII Art welcome screen (Console)
- Voice Greeting (Console)
- GitHub Actions placeholder

## How to Run

### Console Version
Run `dotnet run` in the `ConsoleApp` folder.

### WPF Version
Open the solution in Visual Studio and run the `CybersecurityChatbotWPF` project.
